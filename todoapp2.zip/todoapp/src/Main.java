import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        DBlogic dbLogic = new DBlogic();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("TO-DO List Application");
            System.out.println("1. Add a new TO-DO");
            System.out.println("2. Delete a TO-DO");
            System.out.println("3. View all TO-DOs");
            System.out.println("4. Edit a TO-DO");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1 -> {
                    System.out.print("Enter the new TO-DO: ");
                    String newToDo = scanner.nextLine();
                    dbLogic.saveToDo(newToDo);
                    System.out.println("TO-DO saved successfully!");
                }
                case 2 -> {
                    System.out.print("Enter the ID of the TO-DO to delete: ");
                    int todoIdToDelete = scanner.nextInt();
                    dbLogic.deleteToDo(todoIdToDelete);
                    System.out.println("TO-DO deleted successfully!");
                }
                case 3 -> {
                    System.out.println("All TO-DOs:");
                    dbLogic.viewAllToDos();
                }
                case 4 -> {
                    System.out.print("Enter the ID of the TO-DO to edit: ");
                    int todoIdToEdit = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter the updated TO-DO: ");
                    String updatedToDo = scanner.nextLine();
                    dbLogic.editToDo(todoIdToEdit, updatedToDo);
                    System.out.println("TO-DO edited successfully!");
                }
                case 5 -> {
                    System.out.println("Exiting TO-DO List Application.");
                    scanner.close();
                    System.exit(0);
                }
                default -> System.out.println("Invalid choice. Please try again.");
            }

            System.out.println();
        }
    }
}